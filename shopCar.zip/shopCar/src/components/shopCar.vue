<template>
<div class="car">
  <div class="goods">
    <div class="product" v-for="(item,index) in shopCarList" :key="index">
      <div class="container-fluid">
        <div class="row">
          <div class="col-sm-2">
            <h1>{{item.id}}号商品</h1>
          </div>
          <div class="col-sm-3">
            <div class="price">￥{{item.price}}</div>
          </div>
          <div class="col-sm-4">
            <div class="shopVal">
              <input :disabled="item.num ==1?true:false" 
                      @click="sub(item.id)" 
                      type="button" 
                      value=" - ">
              <input type="text" :value="item.num">
              <input @click="add(item.id)"  type="button" value=" + ">
            </div>
          </div>
          <div class="col-sm-3">
              <button @click="del(item.id)" type="button" class=" del btn btn-success">删除</button>
          </div>
        </div>
      </div>
    </div>    
    <div class="total">
      <h2>总计:</h2>
      <span>总共购买商品数量: <b>{{goodsTalNum}}</b> 件</span>
      <span>总价: <b>{{goodsTalPrice}}</b> 元</span>
    </div>
</div>
</div>
</template>

<script>
export default {
  computed: {
      shopCarList () {
        return this.$store.state.shopCarList;
      },
      goodsTalNum () {
        return this.$store.state.goodsTalNum;
      },
       goodsTalPrice () {
        return this.$store.state.goodsTalPrice;
      }
    },
  methods: {
    sub (id){
        this.$store.commit('SUB_SHOPCARVAL',id);
        this.$store.commit('SHOPCAR_TOTALNUM',id);
        this.$store.commit('SHOPCAR_TOTALPRICE',id);
    },
    add (id) {
        this.$store.commit('ADD_SHOPCARVAL',id);
        this.$store.commit('SHOPCAR_TOTALNUM',id);
        this.$store.commit('SHOPCAR_TOTALPRICE',id);
    },
    del (id) {
        this.$store.commit('DEL_GOODS',id);
        this.$store.commit('SHOPCAR_TOTALNUM',id);
        this.$store.commit('SHOPCAR_TOTALPRICE',id);
    }

  }
}
</script>

<style scoped>
    .car {
      margin-top: 20px;
      padding: 20px;
    }
    .product {
      height: 100px;
      border-bottom: 1px solid #ccc;
      padding-top: 30px;
    }
    .product .price {
      font-size: 30px;
    }
    .shopVal {
      display: inline-block;
      width: 150px;
      margin-top: 10px;
    }
    .shopVal input:nth-of-type(2) {
      width: 60px;
      text-align: center;
    }
    .del {
      margin-top: 10px;
    }
    .total {
      margin-top: 20px;
      border-radius: 5px;
      background-color: #ccc;
      padding: 20px;
    }
    h2 {
      margin-bottom: 20px;
    }
    span {
      font-size: 20px;
    }
    b {
      color: #f40;
    }
    .first {
      position: relative;
    }
    .price {
      color: #f40;
      margin-left: 20px;
      font-size: 20px;
    }
</style>
