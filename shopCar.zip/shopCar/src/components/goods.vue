<template>
  <div id="goods">
    <div class="container-fluid">
        <div class="row">
            <div class="col-md-4" v-for="(item,index) in goodsList" :key="index">
              <div class="first" >
                <h1>{{item.id}}号商品</h1>
                <div class="price">￥{{item.price}}</div>
                <div class="shopVal">
                  <input  :disabled="item.num ==1?true:false"                       @click="sub(item.id)" 
                          type="button" 
                          value=" - ">
                  <input type="text" :value="item.num">
                  <input @click="add(item.id)"  type="button" value=" + ">
                </div>
                <button @click="addShopCar(item.id)" type="button" class=" buy btn btn-danger">加入购物车</button>
              </div>
            </div>
        </div>
    </div>
  </div>
</template>
<script>
export default {
   computed: {
      goodsList () {
        return this.$store.state.goodsList;
      }
    },
    methods: {
      sub(id){
          this.$store.commit('SUB_GOODSlIST',id);
      },
      add(id) {
         this.$store.commit('ADD_GOODSlIST',id);
      },
      addShopCar(id) {
        this.$store.commit('ADD_SHOPCAR',id);
         this.$store.commit('SHOPCAR_TOTALNUM');
         this.$store.commit('SHOPCAR_TOTALPRICE');
      }
    }
}
</script>
<style scoped>
    #goods {
      width: 100%;
      height: 500px;
      margin-top: 30px;
    }
    #goods .row div {
      padding: 10px;
    }
    #goods .row .first {
      border: 1px solid #ccc;
      width: 100%;
      height: 100%;
      padding: 20px;
    } 
    #goods .row .first .price {
      font-size: 20px;
      color: #f40;
      font-weight: bold;
    }
    #goods .row .first .shopVal {
      width: 150px;
      margin-top: 30px;
    }
    #goods .row .first .shopVal input:nth-of-type(2) {
      width: 60px;
      text-align: center;
    }
    #goods .row .first .buy {
      margin-top: 20px;
    }
</style>

