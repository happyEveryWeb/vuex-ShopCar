import Vue from 'vue'
import Router from 'vue-router'
import shopCar from '@/components/shopCar'
import goods from '@/components/goods'

Vue.use(Router)

export default new Router({
  routes: [
    {
      path: '/goods',
      name: 'goods',
      component: goods
    },
    {
      path: '/shopCar',
      name: 'shopCar',
      component: shopCar
    },
    {
      path: '/',
      name: 'index',
      redirect: '/goods'
    }
  ]
})
