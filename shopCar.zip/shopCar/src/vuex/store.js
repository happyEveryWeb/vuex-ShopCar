import Vue from 'vue'
import Vuex from 'vuex'

Vue.use(Vuex)   

const state = {
    goodsList: [],      //商品列表
    shopCarList: [],     //购物车列表
    goodsTalNum: 0,      //购买商品数量
    goodsTalPrice: 0     //购买商品总价格
}

var goodsData = [
    {"id" : 1, "price" : 999, "num" : 1},
    {"id" : 2, "price" : 1999, "num" : 1},
    {"id" : 3, "price" : 2999, "num" : 1}
]
localStorage.setItem("goodsList",JSON.stringify(goodsData));

//用户在刷新页面的时候自动加载数据
localStorage.getItem("goodsList")?
state.goodsList =JSON.parse( localStorage.getItem("goodsList") ):false
localStorage.getItem("shopCarList")?
state.shopCarList =JSON.parse( localStorage.getItem("shopCarList") ):false

//(function(){
    var totalNum = 0;
    for(var k in state.shopCarList) {
        var num = (state.shopCarList[k].num - 0);
        totalNum += num; 
    }
    state.goodsTalNum = totalNum;
//})()


var totalPrice = 0;
for(var k in state.shopCarList) {
    var num = (state.shopCarList[k].num - 0);
    var price = (state.shopCarList[k].price - 0);
    totalPrice += (num * price);
}
state.goodsTalPrice = totalPrice;

 const mutations = {
    SUB_GOODSlIST ( state, id ) {
        for(var k in state.goodsList) {
            if(state.goodsList[k].id == id) {
                if(state.goodsList[k].num > 1) {
                state.goodsList[k].num = (state.goodsList[k].num - 0) - 1;
                break;
                }
            }
        }
        localStorage.setItem("goodsList",JSON.stringify(state.goodsList));
    },
    ADD_GOODSlIST( state, id ) {
        for(var k in state.goodsList) {
            if(state.goodsList[k].id == id) {
                state.goodsList[k].num = (state.goodsList[k].num - 0) + 1;
                break;
            }
        }
        localStorage.setItem("goodsList",JSON.stringify(state.goodsList));
    },
    ADD_SHOPCAR( state, id ) {
        for(var k in state.goodsList) {
            if(state.goodsList[k].id == id) {   
                    //state.shopCarList.push(state.goodsList[k]);
                    //不能直接使用这种方法直接添加，num的动态性质会影响总值
            var num2 = state.goodsList[k].num;
            var id = state.goodsList[k].id;
            var price = state.goodsList[k].price;
                //if(state.shopCarList.length == 0) {
                //    var obj = {"id": id,"price": price, "num": num2};
                    //  state.shopCarList.push(obj);
                //}else {
                    var flag = true;
                    for(var i in state.shopCarList) {
                        if(state.shopCarList[i].id == id) {
                            state.shopCarList[i].num = num2 +(state.shopCarList[i].num - 0);
                            flag = false;
                            break;
                        }
                    }
                    if(flag) {
                        var obj = {"id": id,"price": price, "num": num2};
                        state.shopCarList.push(obj);
                    }
                //}
            }
        }
        localStorage.setItem("shopCarList",JSON.stringify(state.shopCarList));
    },
    SUB_SHOPCARVAL( state, id ) {
        for(var k in state.shopCarList) {
            if(state.shopCarList[k].id == id) {
                if(state.shopCarList[k].num > 1) {
                    state.shopCarList[k].num = (state.shopCarList[k].num - 0) - 1;
                    break;
                }
            }
        }
        localStorage.setItem("shopCarList",JSON.stringify(state.shopCarList));
    },
    ADD_SHOPCARVAL( state, id ) {
        for(var k in state.shopCarList) {
            if(state.shopCarList[k].id == id) {
                state.shopCarList[k].num = (state.shopCarList[k].num - 0) + 1;
                break;
            }
        }
        localStorage.setItem("shopCarList",JSON.stringify(state.shopCarList));
    },
      //计算购物总数量和总价格
    SHOPCAR_TOTALNUM( state ) {
        //总结，不能直接对state数据进行操作，只能最后进行赋值操作
        var totalNum = 0;
        for(var k in state.shopCarList) {
            var num = (state.shopCarList[k].num - 0);
            totalNum += num; 
        }
        state.goodsTalNum = totalNum;
        //console.log(totalNum);
    },
    SHOPCAR_TOTALPRICE( state ) {
        var totalPrice = 0;
        for(var k in state.shopCarList) {
            var num = (state.shopCarList[k].num - 0);
            var price = (state.shopCarList[k].price - 0);
            totalPrice += (num * price);
        }
        state.goodsTalPrice = totalPrice;
        //console.log(totalPrice);
    },
    DEL_GOODS( state, id ) {
        for(var i=0;i<state.shopCarList.length;i++) {
            if(state.shopCarList[i].id == id) {
                state.shopCarList.splice(i,1);
            }
        }
        localStorage.setItem("shopCarList",JSON.stringify(state.shopCarList));
    }
 }

 export default new Vuex.Store({
     state,
     mutations
 })