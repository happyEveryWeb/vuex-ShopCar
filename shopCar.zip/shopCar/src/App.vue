<template>
  <div id="app">
    <h1>兜兜有糖 store</h1>
    
    <router-view/>

     <div class="footer">
        <div class="container-fluid">
          <div class="row">
                <div class="col-xs-6">
                  <router-link to="/goods">
                    <span class="glyphicon glyphicon-heart" aria-hidden="true"></span> <br>
                    goods
                  </router-link>
                </div>
                <div class="col-xs-6">
                  <router-link to="/shopCar">
                    <span class="glyphicon glyphicon-piggy-bank" aria-hidden="true"></span> <br>
                    shopCar
                  </router-link>
                </div>
            </div>
        </div>
    </div>
  </div>
</template>

<script>
export default {

}
</script>

<style scoped>
#app  h1{
  height: 50px;
  width: 100%;
  background-color: #0094ff;
  color: #fff;
  text-align: center;
  line-height: 50px;
}
  .footer {
    position: fixed;
    left: 0;
    bottom: 0;
    height: 50px;
    width: 100%;
    background-color: rgba(255,80,0, .8);
    text-align: center;
  }
  .footer .row {
    margin-top: 10px;
  }
</style>
