import Vue from 'vue'
import App from './App'
import router from './router' //router
import axios from 'axios'     //axios
import $ from 'jquery'
import 'bootstrap/dist/css/bootstrap.min.css'
import 'bootstrap/dist/js/bootstrap.min.js'
import './assets/reset.css'

import Vuex from 'vuex'   //vuex
import store from './vuex/store.js'
Vue.use(Vuex)

Vue.prototype.$https = axios

new Vue({
  el: '#app',
  router,
  store,
  render:c => c(App)
})
